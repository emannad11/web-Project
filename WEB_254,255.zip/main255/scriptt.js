function showAlert() {
    alert("Successfully reached on Registration Process of Little Explorers");
    window.location.href ="registration.html";
}